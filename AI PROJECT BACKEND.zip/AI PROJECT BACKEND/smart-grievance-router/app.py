from flask import Flask, render_template, request

app = Flask(__name__)


def classify_complaint(complaint_text):
    """
    Analyzes complaint text and returns the appropriate department
    based on keyword matching.
    
    Args:
        complaint_text: The user's complaint as a string
    
    Returns:
        A string containing the department name
    """

    text = complaint_text.lower()
    
 
    departments = {
        "Water Department": ["water", "leakage", "pipe", "tap", "drain"],
        "Electricity Department": ["electricity", "power", "current", "light", "wire"],
        "Roads Department": ["road", "pothole", "street", "footpath", "traffic"],
        "Sanitation Department": ["garbage", "waste", "cleaning", "trash", "dustbin"]
    }
    
  
    for department, keywords in departments.items():
        for keyword in keywords:
            if keyword in text:
                return department
    
    
    return "General Department"


@app.route("/", methods=["GET", "POST"])
def index():
    """
    Handles both displaying the form (GET) and processing submissions (POST).
    """
    result = None  
    name = ""
    complaint = ""
    
    if request.method == "POST":
      
        name = request.form.get("name", "").strip()
        complaint = request.form.get("complaint", "").strip()
      
        if name and complaint:
           
            department = classify_complaint(complaint)
            result = {
                "name": name,
                "complaint": complaint,
                "department": department
            }
    
    return render_template("index.html", result=result, name=name, complaint=complaint)


if __name__ == "__main__":
    
    app.run(debug=True)
